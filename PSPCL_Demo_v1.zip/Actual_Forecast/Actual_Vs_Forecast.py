import pandas as pd
import sqlite3


def fetch_data_from_tables_1():
    # Define the database name
    db_name = 'load_forecasting_db_1.db'

    # Connect to the database
    conn = sqlite3.connect(db_name)

    # Query data from the tables using JOIN operation
    query = """
            SELECT f.Datetime, f.Forecasted_Value, l.Value
            FROM Forecast_DB_1 AS f
            INNER JOIN Load_Data_Daily_1 AS l
            ON f.Datetime = l.Datetime
            """

    # Fetch data into a DataFrame
    df = pd.read_sql(query, conn)

    # Close connection
    conn.close()

    return df

# Example usage:
# fetched_data = fetch_data_from_tables()
