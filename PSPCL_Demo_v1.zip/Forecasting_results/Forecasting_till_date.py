import sqlite3

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor


def train_and_forecast_total(df, model_type):
    # Define the database name and table name
    db_name = 'load_forecasting_db_1.db'
    table_name = 'Forecast_DB_1'

    # Pick start datetime and end datetime from the dataframe index
    start_datetime = df.index[0]
    end_datetime = df.index[-1]

    # Calculate daily_l with 15-minute intervals
    daily_rng = pd.date_range(start=start_datetime, end=end_datetime, freq='15T')
    daily_l = len(daily_rng)

    train_data, test_data = train_test_split(df, test_size=0.2, shuffle=False)
    exog_train = train_data[['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]
    exog_test = test_data[['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]

    # Set up endogenous variable
    endog_train = train_data['Value']
    endog_test = test_data['Value']

    if model_type == "ARIMA":
        # Train ARIMA model
        model = ARIMA(endog_train, exog=exog_train, order=(1, 0, 2))
        arima_model = model.fit()

        # Forecasting for next day with 15-minute intervals
        exog_forecast = exog_test  # Use test exog variables for forecasting
        forecast_daily = arima_model.forecast(steps=len(exog_forecast), exog=exog_forecast)

    elif model_type == "XGBoost":
        # Train XGBoost model
        model = XGBRegressor(objective='reg:squarederror', n_estimators=10, seed=42)
        model.fit(exog_train, endog_train)

        # Forecasting for next day with 15-minute intervals
        exog_forecast = exog_test  # Use test exog variables for forecasting
        forecast_daily = model.predict(exog_forecast)

    elif model_type == "Exponential Smoothing":
        # Train Exponential Smoothing model
        model = ExponentialSmoothing(endog_train)
        exp_smooth_model = model.fit()

        # Forecasting for next day with 15-minute intervals
        forecast_daily = exp_smooth_model.forecast(steps=len(exog_test))

    elif model_type == "Linear Regression":
        # Train Linear Regression model
        model = LinearRegression()
        model.fit(exog_train, endog_train)

        exog_forecast = exog_test  # Use test exog variables for forecasting
        forecast_daily = model.predict(exog_forecast)

    else:
        raise ValueError("Invalid model type")

    # Return the forecasting result dataframe
    return pd.DataFrame({'Datetime': test_data.index, 'Forecasted_Value': np.round(forecast_daily, 0)})


def save_dataframe_to_table(df):
    # Define the database name
    db_name = 'load_forecasting_db_1.db'
    table_name = 'Forecast_DB_1'

    # Connect to the database
    conn = sqlite3.connect(db_name)

    # Save the dataframe to the specified table
    df.to_sql(table_name, conn, if_exists='replace', index=False)

    # Commit changes and close connection
    conn.commit()
    conn.close()


def fetch_data_from_table(table_name):
    # Define the database name
    db_name = 'load_forecasting_db_1.db'

    # Connect to the database
    conn = sqlite3.connect(db_name)

    # Query data from the table
    query = f"SELECT * FROM {table_name}"

    # Fetch data into a DataFrame
    df = pd.read_sql(query, conn)

    # Close connection
    conn.close()

    return df

