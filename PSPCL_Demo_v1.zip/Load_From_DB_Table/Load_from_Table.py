import pandas as pd
import sqlite3
import warnings
warnings.filterwarnings("ignore")

def fetch_data(db_path, table_name):
    # Connect to the database
    conn = sqlite3.connect(db_path)

    # Fetch all data from the specified table
    query = f"SELECT * FROM {table_name}"
    df = pd.read_sql(query, conn)

    # Close the connection
    conn.close()

    return df