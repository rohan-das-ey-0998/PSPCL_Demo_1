import sqlite3
import pandas as pd
import datetime as datetime
import warnings
warnings.filterwarnings("ignore")


def process_dataframe_and_store(df, db_path, table_name):
    # Connect to the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Check if the table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
    table_exists = cursor.fetchone()

    if not table_exists:
        # Table doesn't exist, so create it
        cursor.execute(f"CREATE TABLE {table_name} (Datetime DATETIME, Value FLOAT)")
        print(f"Table '{table_name}' created successfully.")

    # Check if the table has required columns
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = cursor.fetchall()
    column_names = [col[1] for col in columns]
    if 'Datetime' not in column_names or 'Value' not in column_names:
        # Table doesn't have required columns, so add them
        cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN Datetime DATETIME")
        cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN Value FLOAT")
        print("Columns 'Datetime' and 'Value' added to table.")

    # Check if the table contains any data
    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
    data_count = cursor.fetchone()[0]
    if data_count > 0:
        # Table contains data, calculate start datetime and end datetime
        cursor.execute(f"SELECT MIN(Datetime), MAX(Datetime) FROM {table_name}")
        start_datetime, end_datetime = cursor.fetchone()
        print(f"Start datetime: {start_datetime}, End datetime: {end_datetime}")

    # Check if the passed DataFrame has required columns
    if 'Datetime' not in df.columns or 'Value' not in df.columns:
        print("Error: DataFrame is missing required columns 'Datetime' and/or 'Value'.")
        return

    # Filter data from DataFrame to insert after end datetime
    if data_count > 0:
        df_to_insert = df[df['Datetime'] > end_datetime]
    else:
        df_to_insert = df

    # Insert data into the table
    if not df_to_insert.empty:
        df_to_insert.to_sql(table_name, conn, if_exists='append', index=False)
        print("Data ingested successfully.")
    else:
        print("No new data to ingest.")

    # Close the connection
    conn.close()
