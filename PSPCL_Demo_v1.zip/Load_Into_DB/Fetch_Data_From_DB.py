import sqlite3
import pandas as pd
import warnings
warnings.filterwarnings("ignore")


def get_table_as_dataframe(db_name, table_name):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_name)

    # Query data from the table
    query = f"SELECT * FROM {table_name};"
    df = pd.read_sql_query(query, conn)

    # Close the database connection
    conn.close()

    return df
