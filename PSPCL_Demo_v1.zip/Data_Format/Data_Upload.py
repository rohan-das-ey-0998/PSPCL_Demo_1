import pandas as pd
import datetime
import warnings

warnings.filterwarnings("ignore")


# def process_file(uploaded_file):
#     # Check if the file format is supported (CSV or Excel)
#     if uploaded_file.name.endswith('.csv'):
#         # Read the uploaded file as a DataFrame
#         df = pd.read_csv(uploaded_file)
#     elif uploaded_file.name.endswith(('.xls', '.xlsx')):
#         # Read the uploaded Excel file as a DataFrame
#         df = pd.read_excel(uploaded_file)
#     else:
#         raise ValueError("Unsupported file format! Please upload a CSV or Excel file.")
#
#     # Convert from wide to long format
#     df_long = pd.melt(df, id_vars=['Time Block'], var_name='Date', value_name='Value')
#
#     # Extract the dates from the 'Date' column
#     df_long['Date'] = pd.to_datetime(df_long['Date']).dt.date
#
#     # Merge 'Time Block' and 'Date' columns and convert to datetime format
#     df_long['Datetime'] = pd.to_datetime(
#         df_long['Date'].astype(str) + ' ' + df_long['Time Block'].str.split('-').str[0], format='%Y-%m-%d %H%M')
#
#     # Select only 'Datetime' and 'Value' columns and drop the rest
#     df_long = df_long[['Datetime', 'Value']]
#
#     return df_long


def process_file(uploaded_file):
    # Check if the file format is supported (CSV or Excel)
    if uploaded_file.name.endswith('.csv'):
        # Read the uploaded file as a DataFrame
        df = pd.read_csv(uploaded_file)
    elif uploaded_file.name.endswith(('.xls', '.xlsx')):
        # Read the uploaded Excel file as a DataFrame
        df = pd.read_excel(uploaded_file)
    else:
        raise ValueError("Unsupported file format! Please upload a CSV or Excel file.")

    # Convert from wide to long format
    df_long = pd.melt(df, id_vars=['Time Block'], var_name='Date', value_name='Value')

    # Extract the dates from the 'Date' column and convert to 'DD-MM-YYYY' format
    df_long['Date'] = pd.to_datetime(df_long['Date']).dt.strftime('%d-%m-%Y')

    # Merge 'Time Block' and 'Date' columns and convert to datetime format
    df_long['Datetime'] = pd.to_datetime(
        df_long['Date'] + ' ' + df_long['Time Block'].str.split('-').str[0], format='%d-%m-%Y %H%M')

    # Select only 'Datetime' and 'Value' columns and drop the rest
    df_long = df_long[['Datetime', 'Value']]

    return df_long


