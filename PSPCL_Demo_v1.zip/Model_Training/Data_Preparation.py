import pandas as pd
import holidays
import warnings
import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, kpss

warnings.filterwarnings("ignore")


def preprocess_data(df):
    # Convert 'Datetime' column to datetime format
    df['Datetime'] = pd.to_datetime(df['Datetime'])

    # Function to check if a date is a weekend
    def is_weekend(date):
        if date.dayofweek >= 5:
            return 1
        else:
            return 0

    # Add 'Weekend' column
    df['Weekend'] = df['Datetime'].apply(is_weekend)

    # Add 'month' column
    df['month'] = df['Datetime'].dt.month

    # Add 'season' column
    df['season'] = df['month'] % 12 // 3 + 1

    # Add 'holiday' column
    in_holidays = holidays.country_holidays('IN',state="PB")
    df['holiday'] = df['Datetime'].apply(lambda d: d in in_holidays).astype(int)

    # Set 'Datetime' column as index
    df.set_index('Datetime', inplace=True)

    # Remove duplicate index values
    df = df[~df.index.duplicated()]

    # Drop the 'month' column
    df = df.drop(columns=['month'])

    return df


def add_lag_features(df, col):
    for n_hours in range(1, 3):
        shifted_col = df[col].shift(n_hours)
        shifted_col = shifted_col.loc[df.index.min(): df.index.max()]
        label = f"{col}_lag_{n_hours}"
        df[label] = np.nan
        df.loc[shifted_col.index, label] = shifted_col
    return df


def preprocess_outliers(df):
    # Function to identify and remove outliers using Winsorization
    def winsorize_column(col):
        q1 = col.quantile(0.25)
        q3 = col.quantile(0.75)
        iqr = q3 - q1
        upper_fence = q3 + (1.5 * iqr)
        lower_fence = q1 - (1.5 * iqr)
        return np.where(col >= upper_fence, upper_fence,
                        np.where(col <= lower_fence, lower_fence, col))

    # Calculate the number of outliers and perform Winsorization
    for col in df.select_dtypes(include=np.number).columns:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        upper_fence = q3 + (1.5 * iqr)
        lower_fence = q1 - (1.5 * iqr)
        outliers = df[(df[col] < lower_fence) | (df[col] > upper_fence)]
        if len(outliers) > 0:
            print("Outliers in " + col)
            print(outliers)
            print()
            # Winsorize the column
            df[col] = winsorize_column(df[col])

    return df


def stationarity_check(df):
    # Drop null values
    df.dropna(inplace=True)

    # # Perform ADF test
    # adf_result = adfuller(df)
    # adf_p_value = adf_result[1]
    #
    # # Perform Phillips-Perron test
    # pp_test = sm.tsa.stattools.adfuller(df, regression='c', autolag='AIC')
    # pp_p_value = pp_test[1]
    #
    # # Check if both p-values are less than 0.05
    # if adf_p_value < 0.05 and pp_p_value < 0.05:
    #     # Data is already stationary
    #     return df
    # else:
    #     # Apply differencing to make the data stationary
    #     df_diff = df.diff().dropna()
    #     return df_diff
    return df

