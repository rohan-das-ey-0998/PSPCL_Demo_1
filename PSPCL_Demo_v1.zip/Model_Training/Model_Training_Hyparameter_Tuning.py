import warnings

warnings.filterwarnings("ignore")

from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.linear_model import LinearRegression
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV


def evaluate_models(df):
    # Initialize lists to store results
    results = []

    # # Standard scaler
    # sc = StandardScaler()

    # Split the data into train and test sets
    train_data, test_data = train_test_split(df, test_size=0.1, shuffle=False)

    # Set up exogenous variables
    # exog_train = train_data[['Value_lag_1', 'Value_lag_2']]  # Assuming 2 lags for all models
    # exog_test = test_data[['Value_lag_1', 'Value_lag_2']]

    exog_train = train_data[
        ['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]  # Assuming 2 lags for all models
    exog_test = test_data[['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]

    # Set up endogenous variable
    endog_train = train_data['Value']
    endog_test = test_data['Value']

    # ARIMA model
    arima_model = ARIMA(endog_train, exog=exog_train, order=(1, 0, 2))
    arima_model_fit = arima_model.fit()
    arima_forecast = arima_model_fit.forecast(steps=len(endog_test), exog=exog_test)
    arima_metrics = evaluate_forecast(endog_test, arima_forecast)
    results.append(('ARIMA',) + arima_metrics)

    # XGBoost model
    xgb_model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=10, seed=42)
    xgb_model.fit(exog_train, endog_train)
    xgb_forecast = xgb_model.predict(exog_test)
    xgb_metrics = evaluate_forecast(endog_test, xgb_forecast)
    results.append(('XGBoost',) + xgb_metrics)

    # Exponential Smoothing model
    exp_model = ExponentialSmoothing(endog_train)
    exp_model_fit = exp_model.fit()
    exp_forecast = exp_model_fit.forecast(len(endog_test))
    exp_metrics = evaluate_forecast(endog_test, exp_forecast)
    results.append(('Exponential Smoothing',) + exp_metrics)

    # Linear Regression model
    lr_model = LinearRegression()
    lr_model.fit(exog_train, endog_train)
    lr_forecast = lr_model.predict(exog_test)
    lr_metrics = evaluate_forecast(endog_test, lr_forecast)
    results.append(('Linear Regression',) + lr_metrics)

    # Create a dataframe to store results
    columns = ['Model', 'RMSE', 'MSE', 'MAE', 'R2', 'MAPE', 'SMAPE']
    results_df = pd.DataFrame(results, columns=columns)

    return results_df


def evaluate_forecast(actual, forecast):
    rmse = np.sqrt(mean_squared_error(actual, forecast))
    mse = mean_squared_error(actual, forecast)
    mae = mean_absolute_error(actual, forecast)
    r2 = r2_score(actual, forecast)
    mape = round(np.mean(abs((actual - forecast) / actual)) * 100, 4)
    smape = round(np.mean(2 * abs(forecast - actual) / (abs(forecast) + abs(actual))) * 100, 4)
    return rmse, mse, mae, r2, mape, smape


def find_best_model(df):
    # Sort the dataframe by MAPE and SMAPE values in ascending order
    sorted_df = df.sort_values(by=['MAPE', 'SMAPE'], ascending=True)

    # Get the model name with the lowest MAPE and SMAPE values
    best_model = sorted_df.iloc[0]['Model']

    return best_model


def train_and_forecast(daily_l, df, model_type):
    train_data, test_data = train_test_split(df, test_size=0.2, shuffle=False)
    exog_train = train_data[['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]
    exog_test = test_data[['Weekend', 'season', 'holiday', 'Value_lag_1', 'Value_lag_2']]

    # Set up endogenous variable
    endog_train = train_data['Value']
    endog_test = test_data['Value']

    if model_type == "ARIMA":
        # # Train ARIMA model
        model = ARIMA(endog_train, exog=exog_train, order=(1, 0, 2))
        arima_model = model.fit()

        # Forecasting for next day
        exog_forecast = exog_train[-daily_l:]
        forecast_daily = arima_model.forecast(steps=daily_l, exog=exog_forecast)

    elif model_type == "XGBoost":
        # # Train XGBoost model
        model = XGBRegressor(objective='reg:squarederror', n_estimators=10, seed=42)
        model.fit(exog_train, endog_train)

        # # Forecasting for next day
        exog_forecast = exog_train[-daily_l:]
        forecast_daily = model.predict(exog_forecast)

    elif model_type == "Exponential Smoothing":
        # # Train Exponential Smoothing model
        model = ExponentialSmoothing(endog_train)
        exp_smooth_model = model.fit()

        # # Forecasting for next day
        exog_forecast = exog_train[-daily_l:]
        forecast_daily = exp_smooth_model.forecast(exog_forecast)


    elif model_type == "Linear Regression":
        # Train Linear Regression model
        model = LinearRegression()
        model.fit(exog_train, endog_train)

        exog_forecast = exog_train[-daily_l:]
        forecast_daily = model.predict(exog_forecast)

    else:
        raise ValueError("Invalid model type")

    return forecast_daily

