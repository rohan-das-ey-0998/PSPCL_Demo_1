import sqlite3
import os
import warnings
warnings.filterwarnings("ignore")


# Function to check if SQLite database and table exist, and create them if necessary
def setup_database():
    db_name = 'load_forecasting_db_1.db'
    table_name = 'Load_Data_Daily_1'

    # Check if database exists
    if not os.path.exists(db_name):
        conn = sqlite3.connect(db_name)
        cursor = conn.cursor()
        cursor.execute(f'''CREATE TABLE {table_name} (
                            Datetime TEXT PRIMARY KEY,
                            Value REAL
                        );''')
        conn.commit()
        conn.close()

    return os.path.abspath(db_name), table_name
